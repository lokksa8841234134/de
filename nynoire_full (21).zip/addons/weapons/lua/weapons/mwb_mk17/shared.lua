--[[-------------------------------------------------------------------------
    Project: New York Noire - Core Framework Рефакторинг
    Author: Spoffer Dev Team
    Environment: Shared / Client / Server Core Modules
    Note: Чистая среда разработки. Локальная рабочая копия.
---------------------------------------------------------------------------]]
AddCSLuaFile()
PrecacheParticleSystem("AC_muzzle_rifle")
PrecacheParticleSystem("AC_muzzle_pistol_suppressed")
PrecacheParticleSystem("AC_muzzle_pistol_ejection")
PrecacheParticleSystem("AC_muzzle_pistol_smoke_barrel")
include("animations.lua")
include("customization.lua")

if CLIENT then
	killicon.Add("mg_scharlie", "VGUI/entities/mg_scharlie", Color(255, 0, 0, 255))
	SWEP.WepSelectIcon = surface.GetTextureID("VGUI/spawnicons/icon_cac_weapon_ar_scharlie")
end

SWEP.Base = "mg_base"

SWEP.ShellsId = "cases308"
SWEP.AmmoId = "box308"

SWEP.UseMags = {
	["scar_20"] = {1, 2},
	["scar_10"] = {1, 3},
	["scar_25"] = {1, 5},
	["scar_30"] = {1, 6}
}

SWEP.Unloader = {
	["mag_remove"] = 0.9,
	["skip_cycle"] = 0,
	["anim"] = "Reload_Empty",
	["anim_swap"] = "Equip",
	["load_cycle"] = 0.3,
}

SWEP.GripPoseParameters = {"grip_ang_offset", "grip_vert_offset", "grip_vert_pro_offset", "grip_vert_large_offset", "grenade_launcher_offset"}

SWEP.PrintName = "FN SCAR 17"
SWEP.Category = "Modern Warfare"
SWEP.SubCategory = "Assault Rifles"
SWEP.Spawnable = true
SWEP.VModel = Model("models/viper/mw/weapons/v_scharlie.mdl")
SWEP.WorldModel = Model("models/viper/mw/weapons/w_scharlie.mdl")
SWEP.Slot = 3
SWEP.HoldType = "Rifle"
SWEP.Primary.Sound = Sound("mw19.scharlie.fire")
SWEP.DistSound = "Reflection_Sniper.Distance"
SWEP.Trigger = {
	PressedSound = Sound("mw19.scharlie.fire.first"),
	ReleasedSound = Sound("mw19.scharlie.disconnector"),
	Time = 0.025
}

SWEP.Primary.Ammo = "Ar2"
SWEP.Primary.ClipSize = 20
SWEP.Primary.Automatic = false
SWEP.Primary.BurstRounds = 1
SWEP.Primary.BurstDelay = 0
SWEP.Primary.RPM = 571
SWEP.CanChamberRound = true
SWEP.Resource = .0033

SWEP.ParticleEffects = {
	["MuzzleFlash"] = "AC_muzzle_rifle",
	["MuzzleFlash_Suppressed"] = "AC_muzzle_pistol_suppressed",
	["Ejection"] = "AC_muzzle_pistol_ejection",
}

SWEP.Reverb = {
	RoomScale = 50000, --(cubic hu)
	--how big should an area be before it is categorized as 'outside'?
	Sounds = {
		Outside = {
			Layer = Sound("Atmo_LMG.Outside"),
			Reflection = Sound("Reflection_AR.Outside")
		},
		Inside = {
			Layer = Sound("Atmo_LMG.Inside"),
			Reflection = Sound("Reflection_AR.Inside")
		}
	}
}

SWEP.MalfunctionAnimation = {
	["skip_cycle"] = 0,
	["anim"] = "Equip",
	["next"] = 1,
}

SWEP.Firemodes = {
	[1] = {
		Name = "Semi Auto",
		OnSet = function(self)
			self.Primary.Automatic = false
			return "Firemode_Semi"
		end
	}
}

SWEP.BarrelSmoke = {
	Particle = "AC_muzzle_pistol_smoke_barrel",
	Attachment = "muzzle",
	ShotTemperatureIncrease = 10,
	TemperatureThreshold = 200, --temperature that triggers smoke
	TemperatureCooldown = 8 --degrees per second
}

SWEP.Cone = {
	Hip = 0.45, --accuracy while hip
	Ads = 0.06, --accuracy while aiming
	Shake = 0.4,
	Increase = 0.075, --increase cone size by this amount every time we shoot
	AdsMultiplier = 0.9, --multiply the increase value by this amount while aiming
	Max = 1.85, --the cone size will not go beyond this size
	Decrease = 0.85, -- amount (in seconds) for the cone to completely reset (from max)
	Seed = 587843 --just give this a random number
}

SWEP.Recoil = {
	Vertical = {2, 1.6}, --random value between the 2
	Horizontal = {-2.5, 2.75}, --random value between the 2
	Shake = 1.25, --camera shake
	AdsMultiplier = 0.9, --multiply the values by this amount while aiming
	Seed = 984135 --give this a random number until you like the current recoil pattern
}

SWEP.Bullet = {
	Damage = {70, 45}, --first value is damage at 0 meters from impact, second value is damage at furthest point in effective range
	DropOffStartRange = 100, --in meters, damage will start dropping off after this range
	EffectiveRange = 200, --in meters, damage scales within this distance
	Range = 500, --in meters, after this distance the bullet stops existing
	Tracer = false, --show tracer
	NumBullets = 1, --the amount of bullets to fire
	PhysicsMultiplier = 1, --damage is multiplied by this amount when pushing objects
	HeadshotMultiplier = 1,
	Penetration = {
		DamageMultiplier = 0.9, --how much damaged is multipled by when leaving a surface.
		MaxCount = 4, --how many times the bullet can penetrate.
		Thickness = 21, --in hu, how thick an obstacle has to be to stop the bullet.
	}
}

SWEP.Zoom = {
	FovMultiplier = 0.95,
	ViewModelFovMultiplier = 1,
	Blur = {
		EyeFocusDistance = 7
	}
}

SWEP.WorldModelOffsets = {
	Bone = "tag_sling",
	Angles = Angle(0, 95, -90),
	Pos = Vector(2, -5, -3)
}

SWEP.ViewModelOffsets = {
	Aim = {
		Angles = Angle(0, 0, 0),
		Pos = Vector(0, 3, 0)
	},
	Idle = {
		Angles = Angle(0, 0, 0),
		Pos = Vector(0, 0, 0)
	},
	Inspection = {
		Bone = "tag_sling",
		X = {
			[0] = {
				Pos = Vector(0, 0, 0),
				Angles = Angle(40, 0, -30)
			},
			[1] = {
				Pos = Vector(0, 0, 0),
				Angles = Angle(-10, 0, 0)
			}
		},
		Y = {
			[0] = {
				Pos = Vector(0, 0, 0),
				Angles = Angle(-10, 20, 0)
			},
			[1] = {
				Pos = Vector(3, 0, 3),
				Angles = Angle(10, -20, 0)
			}
		}
	},
	RecoilMultiplier = 0.8,
	KickMultiplier = 0.6,
	AimKickMultiplier = 1.3,
}

SWEP.Shell = "mwb_shelleject_7625x"