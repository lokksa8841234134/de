--[[-------------------------------------------------------------------------
    Project: New York Noire - Core Framework Рефакторинг
    Author: Spoffer Dev Team
    Environment: Shared / Client / Server Core Modules
    Note: Чистая среда разработки. Локальная рабочая копия.
---------------------------------------------------------------------------]]
AddCSLuaFile()

SWEP.Base = "mlw_base"
SWEP.PrintName = "Труба"
SWEP.Category = "Melee"
SWEP.Slot = 4
SWEP.SlotPos = 5
SWEP.Weight = 30
SWEP.Spawnable = true
SWEP.ViewModel = "models/weapons/tfa_nmrih/v_me_pipe_lead.mdl"
SWEP.WorldModel = "models/weapons/tfa_nmrih/w_me_pipe_lead.mdl"
SWEP.ViewModelFOV = 55
SWEP.AutoSwitchTo = true
SWEP.AutoSwitchFrom = false
SWEP.HitDistance = 50

SWEP.VElements = {}
SWEP.ViewModelBoneMods = {
	["Maglite"] = { scale = Vector(0.001, 0.001, 0.001), pos = Vector(-30, 0, 0), angle = Angle(0, 0, 0) }
}

SWEP.DamageTypes = {
	[1] = {7,17},
	[2] = {13,35}
}

SWEP.ShowWorldModel = false

SWEP.WElements = {
	["wmodel"] = {
		type = "Model",
		model = "models/weapons/tfa_nmrih/w_me_pipe_lead.mdl",
		bone = "ValveBiped.Bip01_R_Hand",
		rel = "",
		pos = Vector(3, 1, -5),
		angle = Angle(180, 90, 0),
		size = Vector(1, 1, 1),
		color = color_white,
		surpresslightning = false,
		material = "",
		skin = 0,
		bodygroup = {}
	}
}